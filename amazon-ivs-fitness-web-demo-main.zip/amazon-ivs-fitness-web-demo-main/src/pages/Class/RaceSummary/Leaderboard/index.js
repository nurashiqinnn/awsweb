export { default } from './Leaderboard';
