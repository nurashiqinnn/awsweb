export { default } from './Class';
